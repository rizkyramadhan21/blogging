<?php
/*-----------------
 Just custom alert
-----------------*/
echo "<script>alert('Simpan data berhasil !'); window.location.href = '../../';</script>";
?>